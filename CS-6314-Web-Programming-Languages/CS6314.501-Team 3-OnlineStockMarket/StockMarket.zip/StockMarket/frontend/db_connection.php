<?php
/**
 * Created by PhpStorm.
 * User: dchha
 * Date: 3/31/2019
 * Time: 11:38 AM
 */

global $connection;
$servername = 'localhost';
$username = 'diksha';
$password = 'diksha';
$dbname = 'webpl';

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
?>